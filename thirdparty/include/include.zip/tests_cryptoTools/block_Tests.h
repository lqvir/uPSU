#pragma once
namespace tests_cryptoTools
{
    void block_operation_test();
};

