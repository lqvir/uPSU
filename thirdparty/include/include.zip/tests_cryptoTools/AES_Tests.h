#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 

namespace tests_cryptoTools
{

    void AES_EncDec_Test();
}