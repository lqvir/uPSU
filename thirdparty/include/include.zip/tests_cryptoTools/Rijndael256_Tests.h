#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use.

#ifdef OC_ENABLE_AESNI
namespace tests_cryptoTools
{
    void Rijndael256_EncDec_Test();
}
#endif // ENABLE_AESNI
