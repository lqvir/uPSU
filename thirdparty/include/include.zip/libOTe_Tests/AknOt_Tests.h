#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 


namespace tests_libOTe
{
    void AknOt_sendRecv1000_Test();
}