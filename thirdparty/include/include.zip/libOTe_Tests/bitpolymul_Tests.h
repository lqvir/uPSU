#pragma once

#include <cryptoTools/Common/CLP.h>

void Tools_bitpolymul_test(const oc::CLP& cmd);
