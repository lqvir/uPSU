#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 


namespace tests_libOTe
{
    void NcoOt_Kkrt_Test();
    void NcoOt_Oos_Test();
    void NcoOt_Rr17_Test();
    void NcoOt_genBaseOts_Test();
    void NcoOt_chosen();

    void Tools_LinearCode_Test();
    void Tools_LinearCode_sub_Test();
    void Tools_LinearCode_rep_Test();
}