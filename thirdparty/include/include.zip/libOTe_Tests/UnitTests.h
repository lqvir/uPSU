#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 
#include <cryptoTools/Common/TestCollection.h>
namespace tests_libOTe
{

    extern osuCrypto::TestCollection Tests;
}
