#pragma once
// This file and the associated implementation has been placed in the public domain, waiving all copyright. No restrictions are placed on its use. 
#include <string>
#include "cryptoTools/Common/TestCollection.h"
namespace tests_libOTe
{
    //
    void InitDebugPrinting(std::string file = "../../testout.txt");
    //
    extern std::string SolutionDir;


}